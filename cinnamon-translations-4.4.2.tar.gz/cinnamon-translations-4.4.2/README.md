cinnamon-translations
=====================

Please note the *cinnamon-translations* GitHub repository is used for
packaging purposes only. If you would like to submit translation
updates, please see the related Launchpad project at
https://translations.launchpad.net/linuxmint/latest/.
